<<<<<<<<<<<<<<  ✨ Codeium Command 🌟 >>>>>>>>>>>>>>>>
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

const ConfirmModal = ({ isOpen, onClose, onConfirm }) => {
  const handleConfirm = () => {
    onConfirm();
    onClose();
  };

  return (
    <div className={`modal ${isOpen ? 'open' : ''}`}>
      <div className="modal-content">
        <h2>Confirmation </h2>
        <p> Are you sure you want to leave this page ? </p>
        <div className="buttons">
          <button onClick={onClose}> Cancel </button>
          <button onClick={handleConfirm}> OK </button>
        </div>
      </div>
    </div>
  );
};

const useUnsavedChangesWarning = (isDirty: boolean) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const handleRouteChangeStart = (url: string) => {
      if (isDirty) {
        setShowConfirmModal(true);
      }
    };

    const handleModalConfirm = () => {
      router.events.emit('routeChangeError');
      throw new Error('routeChange aborted.');
    };

    router.events.on('routeChangeStart', handleRouteChangeStart);

    return () => {
      router.events.off('routeChangeStart', handleRouteChangeStart);
    };
  }, [isDirty, router]);

  return (
    <>
      <ConfirmModal
        isOpen={showConfirmModal}
        onClose={() => setShowConfirmModal(false)}
        onConfirm={handleModalConfirm}
      />
      {/* Rest of the code */}
    </>
  );
import React, { useState } from 'react';

const ConfirmModal = ({ isOpen, onClose, onConfirm }) => {
  const handleConfirm = () => {
    onConfirm();
    onClose();
  };

  return (
    <div className= {`modal ${isOpen ? 'open' : ''}`
}>
  <div className="modal-content" >
    <h2>Confirmation </h2>
    < p > Are you sure you want to leave this page ? </p>
      < div className = "buttons" >
        <button onClick={ onClose }> Cancel </button>
          < button onClick = { handleConfirm } > OK </button>
            </div>
            </div>
            </div>
  );
};

const useUnsavedChangesWarning = (isDirty: boolean) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const handleBrowseAway = () => {
    if (!isDirty) return;
    setShowConfirmModal(true);
  };

  const handleModalClose = () => {
    setShowConfirmModal(false);
  };

  const handleModalConfirm = () => {
    router.events.emit('routeChangeError');
    throw 'routeChange aborted.';
  };

  return (
    <>
    <ConfirmModal
        isOpen= { showConfirmModal }
  onClose = { handleModalClose }
  onConfirm = { handleModalConfirm }
    />
    {/* Rest of the code */ }
    </>
  );
};
<<<<<<<  c4ae06e3-058e-4a32-994d-962e73688c05  >>>>>>>